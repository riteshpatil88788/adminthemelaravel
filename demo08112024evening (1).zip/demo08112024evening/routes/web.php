<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\admin\AdminController;
use App\Http\Controllers\user\UserController;
use App\Http\Controllers\admin\DepartmentController;
use App\Http\Controllers\admin\ProfileController;



Route::get('admin', [AdminController::class, 'index']);
Route::post('logincheck', [AdminController::class, 'logincheck'])->name('logincheck');
Route::post('admin', [AdminController::class, 'logout'])->name('logout');

Route::group(['middleware' => 'admin'], function () {
    Route::get('dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
    Route::get('department-list', [DepartmentController::class, 'departmentlist'])->name('list.department');
    Route::get('add-department', [DepartmentController::class, 'adddepartment'])->name('add.department');
    Route::post('store-department', [DepartmentController::class, 'storedepartment'])->name('store.department');
    Route::get('edit-department/{id}', [DepartmentController::class, 'editdepartment'])->name('edit.department');
    Route::post('update-department/{id}', [DepartmentController::class, 'updatedepartment'])->name('update.department');
    Route::delete('delete-department/{id}', [DepartmentController::class, 'deletedepartment'])->name('delete.department');
    Route::get('edit-profile/{id}', [ProfileController::class, 'editprofile'])->name('admin.editprofile');
    Route::post('update-profile/{id}', [ProfileController::class, 'updateprofile'])->name('admin.updateprofile');
    Route::get('department-pdf', [DepartmentController::class, 'departmentlistpdf'])->name('department.pdf');
    Route::get('export', [DepartmentController::class, 'export'])->name('export');

});


Route::get('user', action: [UserController::class, 'index']);
Route::post('userlogincheck', [UserController::class, 'userlogincheck'])->name(name: 'userlogincheck');
Route::post('user', [UserController::class, 'userlogout'])->name('userlogout');
Route::group(['middleware' => 'web', 'prefix' => 'user'], function () {
    Route::get('dashboard', [UserController::class, 'userdashboard'])->name('userdashboard');

});






// Route::group(['middleware' => 'admin'], function () {
//     Route::get('admin/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
//     Route::get('admin/department-list', [DepartmentController::class, 'departmentlist'])->name('list.department');
//     Route::get('admin/add-department', [DepartmentController::class, 'adddepartment'])->name('add.department');
//     Route::post('admin/store-department', [DepartmentController::class, 'storedepartment'])->name('store.department');
//     Route::get('admin/edit-department/{id}', [DepartmentController::class, 'editdepartment'])->name('edit.department');
//     Route::post('admin/update-department/{id}', [DepartmentController::class, 'updatedepartment'])->name('update.department');
//     Route::delete('admin/delete-department/{id}', [DepartmentController::class, 'deletedepartment'])->name('delete.department');
//     Route::get('admin/edit-profile/{id}', [ProfileController::class, 'editprofile'])->name('admin.editprofile');
//     Route::post('admin/update-profile/{id}', [ProfileController::class, 'updateprofile'])->name('admin.updateprofile');
//     Route::get('admin/department-pdf', [DepartmentController::class, 'departmentlistpdf'])->name('department.pdf');
//     Route::get('admin/export', [DepartmentController::class, 'export'])->name('export');
//     Route::get('get-department/{id}', [DepartmentController::class, 'getdepartment'])->name('list.get-department');


// });