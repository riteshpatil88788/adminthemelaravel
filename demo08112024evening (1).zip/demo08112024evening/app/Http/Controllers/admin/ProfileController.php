<?php

namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Models\Image;
use App\Models\Admin;

class ProfileController extends Controller
{
    public function editprofile(Request $request, $id)
    {
        Admin::findOrFail($id);
        return view('admin.profile.profile');
    }

    public function updateprofile(Request $request, $id)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required',
            'old_password' => 'required',
            'new_password' => 'required',
            'confirm_password' => 'required'

        ]);



        if (!Hash::check($request->old_password, Auth::guard('admin')->User()->password)) {
            return back()->with('error', 'The old password is incorrect.');
        }

        if ($request->new_password !== $request->confirm_password) {
            return back()->with('error', 'The new password and confirm password do not match');
        }


        $user = Admin::find($id);
        Admin::findOrFail($id)->update([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->new_password),


        ]);


        if ($request->hasFile('image')) {
            $imageFile = $request->file('image');
            $name = time() . '_' . $imageFile->getClientOriginalName();
            $imageFile->move(public_path('images'), $name);
            $image = Image::where('imageable_id', $id)->where('imageable_type', 'App\Models\Admin')->first();
            if (!empty($image)) {
                $imagePath = public_path('images/' . $image->imageable_path);
                if (file_exists($imagePath)) {
                    unlink($imagePath);
                }

                Image::where('imageable_id', $id)->where('imageable_type', 'App\Models\Admin')->update([
                    'imageable_path' => $name,
                ]);
            } else {
                $user->images()->create(['imageable_path' => $name]);
            }
        }

        return redirect()->route('admin.editprofile', $id);
    }
}