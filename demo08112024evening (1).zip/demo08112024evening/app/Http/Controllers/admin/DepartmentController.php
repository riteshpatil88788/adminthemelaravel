<?php

namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\DepartmentExport;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\Department;
use App\Models\Image;
use Yajra\DataTables\DataTables;

class DepartmentController extends Controller
{


    public function adddepartment()
    {
        return view('admin.department.add-department');
    }


    public function storedepartment(Request $request)
    {
        $request->validate([
            'department_id' => 'required',
            'department_name' => 'required',
            'hod' => 'required',
            'started_date' => 'required',
            'no_of_students' => 'required',
            'description' => 'required',
            'image' => 'required'

        ]);

        $department = Department::create([
            'department_id' => $request->department_id,
            'department_name' => $request->department_name,
            'hod' => $request->hod,
            'started_date' => Carbon::parse($request->started_date)->format('Y-m-d'),
            'no_of_students' => $request->no_of_students,
            'description' => $request->description
        ]);

        if ($request->hasFile('image')) {
            $imageFile = $request->file('image');
            $name = time() . '_' . $imageFile->getClientOriginalName();
            $imageFile->move(public_path('images'), $name);
            $department->images()->create(['imageable_path' => $name]);
        }

        return redirect()->route('list.department');

    }


    public function editdepartment(Request $request, $id)
    {
        $department = Department::findOrFail(decrypt($id));
        return view('admin.department.edit-department', compact('department'));
    }


    public function updatedepartment(Request $request, $id)
    {
        $request->validate([
            'department_id' => 'required',
            'department_name' => 'required',
            'hod' => 'required',
            'started_date' => 'required',
            'no_of_students' => 'required',
            'description' => 'required',

        ]);

        $department = Department::find($id);
        Department::find($id)->update([
            'department_id' => $request->department_id,
            'department_name' => $request->department_name,
            'hod' => $request->hod,
            'started_date' => Carbon::parse($request->started_date)->format('Y-m-d'),
            'no_of_students' => $request->no_of_students,
            'description' => $request->description,
        ]);

        if ($request->hasFile('image')) {

            $imageFile = $request->file('image');
            $name = time() . '_' . $imageFile->getClientOriginalName();
            $imageFile->move(public_path('images'), $name);

            $image = Image::where('imageable_id', $id)->where('imageable_type', 'App\Models\Department')->first();
            if (!empty($image)) {
                $imagePath = public_path('images/' . $image->imageable_path);
                if (file_exists($imagePath)) {
                    unlink($imagePath);
                }

                Image::where('imageable_id', $id)->where('imageable_type', 'App\Models\Department')->update([
                    'imageable_path' => $name,
                ]);
            } else {

                $department->images()->create(['imageable_path' => $name]);
            }
        }
        return redirect()->route('list.department');
    }


    public function deletedepartment($id)
    {

        $department = Department::find($id);
        $image = Image::where('imageable_id', $id)->first();
        if (!empty($image)) {
            $imagePath = public_path('images/' . $image->imageable_path);

            if (file_exists($imagePath)) {
                unlink($imagePath);
            }

            $image->delete();
        }
        $department->delete();
        return response()->json(['success' => true]);
    }








    public function departmentlist(Request $request)
    {
        if ($request->ajax()) {
            $data = Department::select('id', 'department_name', 'hod', 'started_date', 'no_of_students')->orderBy('id', 'desc')->get();


            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    // $btn = '<a href="' . route("edit.department", $row->id) . '" class="edit btn btn-outline-primary btn-sm" target="_blank">Edit</a>';
                    $btn = '<a href="' . route("edit.department", encrypt($row->id)) . '"  target="_blank"><i class="fas fa-edit"></i></a>';
                    // $btn = $btn . ' <a href="javascript:void(0)" data-toggle="tooltip"  data-id="' . $row->id . '" data-original-title="Delete" class="btn btn-outline-danger btn-sm deleteProduct">Delete</a>';
                    $btn = $btn . ' <a href="javascript:void(0)" data-toggle="tooltip"  data-id="' . $row->id . '" data-original-title="Delete" class="deleteProduct"><i class="fas fa-trash" style="color:red"></i></a>';
                    // $btn = '<a href="' . route("edit.department", encrypt($row->id)) . '"  target="_blank"><i class="fas fa-edit"></i></a>';
                    // $btn = $btn . '<a href="javascript:void(0)" class="viewProduct" data-id="' . $row->id . '" id="test"><i class="fas fa-eye" style="color:black;margin-left:4px;"></i></a>';
                    return $btn;
                })


                ->addColumn('image', function ($row) {
                    $image = $row->images->first();
                    if ($image) {
                        $url = asset("images/{$image->imageable_path}");
                        return '<img src="' . htmlspecialchars($url) . '"  width="50" class="img-rounded" align="center" />';
                    } else {
                        $url = asset("images/dummy-image.png");
                        return '<img src="' . htmlspecialchars($url) . '" width="50" class="img-rounded" align="center" />';
                    }

                })

                ->rawColumns(['action', 'image'])
                ->make(true);


        }
        return view('admin.department.departments');


    }









    public function export()
    {
        return Excel::download(new DepartmentExport, 'department.xlsx');
    }


    public function departmentlistpdf()
    {
        $lists = Department::orderBy('department_name', 'asc')->get();
        $data['lists'] = $lists;
        $pdf = PDF::loadView('admin.department.departmentpdf', $data);
        return $pdf->download('department.pdf');
    }




}