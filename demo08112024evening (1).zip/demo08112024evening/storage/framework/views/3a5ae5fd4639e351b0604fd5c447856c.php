<!DOCTYPE html>
<html>

<head>
    <title>PDF Report</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

    </style>
</head>

<body>
    <h1>Department List</h1>
    <table>
        <thead>
            <tr>
                <th>SNO</th>
                <th>Department ID</th>
                <th>Department Name</th>
                <th>HOD</th>
                <th>Started Date</th>
                <th>No of Students </th>
                <th>Image</th>

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($list->department_id); ?></td>
                <td><?php echo e($list->department_name); ?></td>
                <td><?php echo e($list->hod); ?></td>
                <td><?php echo e($list->started_date); ?></td>
                <td><?php echo e($list->no_of_students); ?></td>
                <td>
                    <?php if($list->images->isNotEmpty()): ?>
                    <img src="<?php echo e(public_path('images/' . $list->images->first()->imageable_path)); ?>" alt="" height="50" width="50">
                    <?php else: ?>
                    <img src="<?php echo e(public_path('images/dummy-image.png')); ?>" alt="No image available" height="50" width="50">
                    <?php endif; ?>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\demo08112024\resources\views/admin/department/departmentpdf.blade.php ENDPATH**/ ?>