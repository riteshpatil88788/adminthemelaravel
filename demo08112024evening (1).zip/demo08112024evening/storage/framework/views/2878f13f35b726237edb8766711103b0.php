<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <div class="ms-auto text-end">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('list.department')); ?>">Department</a></li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Edit Department
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12 mx-auto">
                <div class="card">
                    <form action="<?php echo e(route('update.department',$department->id)); ?>" class="form-horizontal" autocomplete="off" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group row">
                                <label for="department_id" class="col-sm-3 text-end control-label col-form-label">Department Id
                                </label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="department_id" value="<?php echo e($department->department_id); ?>" />
                                    <?php if($errors->has('department_id')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('department_id')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="department_name" class="col-sm-3 text-end control-label col-form-label">Department Name
                                </label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="department_name" value="<?php echo e($department->department_name); ?>" />
                                    <?php if($errors->has('department_name')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('department_name')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="hod" class="col-sm-3 text-end control-label col-form-label">HOD</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="hod" value="<?php echo e($department->hod); ?>" />
                                    <?php if($errors->has('hod')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('hod')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="started_date" class="col-sm-3 text-end control-label col-form-label">Started Date</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="datepicker-autoclose" name="started_date" placeholder="MM/DD/YYYY" value="<?php echo e($department->started_date); ?>" />
                                    <?php if($errors->has('started_date')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('started_date')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="no_of_students" class="col-sm-3 text-end control-label col-form-label">No of students
                                </label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="no_of_students" value="<?php echo e($department->no_of_students); ?>" />
                                    <?php if($errors->has('no_of_students')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('no_of_students')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cono1" class="col-sm-3 text-end control-label col-form-label">Message</label>
                                <div class="col-sm-9">
                                    <textarea class="form-control tinymce" id="editor1" name="description"><?php echo $department->description; ?></textarea>
                                    <?php if($errors->has('description')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="image" class="col-sm-3 text-end control-label col-form-label">Image
                                </label>
                                <?php if(isset( $department->images->first()->imageable_path)): ?>
                                <div class="col-sm-3">
                                    <img src="<?php echo e(url('images/' . $department->images->first()->imageable_path)); ?>" width="50" height="40">
                                </div>
                                <?php else: ?>
                                <div class="col-sm-3">
                                    <img src="<?php echo e(url('images/dummy-image.png')); ?>" width="50" height="50">
                                </div>
                                <?php endif; ?>

                                <div class="col-sm-5">
                                    <input type="file" class="form-control" name="image" value="<?php echo e(old('image')); ?>" />
                                    <?php if($errors->has('image')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                        </div>
                        <div class="border-top">
                            <div class="card-body">
                                <button type="submit" class="btn btn-primary">
                                    Update
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\demo08112024\resources\views/admin/department/edit-department.blade.php ENDPATH**/ ?>