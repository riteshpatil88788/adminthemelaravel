<x-layout>
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <div class="ms-auto text-end">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{route('dashboard')}}">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Profile
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    @if (session('error'))
    <script>
        Swal.fire({
            title: 'Error!'
            , text: "{{ session('error') }}"
            , icon: 'error'
            , confirmButtonText: 'Okay'
        });

    </script>
    @endif

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12 mx-auto">
                <div class="card">
                    <form action="{{ route('admin.updateprofile', Auth::guard('admin')->User()->id) }}" method="POST" autocomplete="off" enctype="multipart/form-data">
                        @csrf
                        <div class="card-body">
                            <div class="form-group row">
                                <label for="department_id" class="col-sm-3 text-end control-label col-form-label">Name
                                </label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="name" value="{{ Auth::guard('admin')->User()->name }}" readonly />
                                    @if($errors->has('name'))
                                    <span class="text-danger">{{$errors->first('name')}}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="email" class="col-sm-3 text-end control-label col-form-label">Email
                                </label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="email" value="{{ Auth::guard('admin')->User()->email }}" readonly />
                                    @if($errors->has('email'))
                                    <span class="text-danger">{{$errors->first('email')}}</span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="image" class="col-sm-3 text-end control-label col-form-label">Image
                                </label>
                                @if(Auth::guard('admin')->user()->images && Auth::guard('admin')->user()->images->isNotEmpty())
                                <div class="col-sm-3">
                                    <img src="{{ url('images/' . Auth::guard('admin')->user()->images->first()->imageable_path) }}" width="40" height="40" />
                                </div>
                                @else
                                <div class="col-sm-3">
                                    <img src="{{ url('images/1.jpg') }}" width="40" height="40" />
                                </div>
                                @endif

                                <div class="col-sm-6">
                                    <input type="file" name="image" value="{{old('image')}}" class="form-control">
                                </div>
                                @if($errors->has('image'))
                                <span class="text-danger">{{$errors->first('image')}}</span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="old_password" class="col-sm-3 text-end control-label col-form-label">Old Password</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="old_password" />
                                @if($errors->has('old_password'))
                                <span class="text-danger">{{$errors->first('old_password')}}</span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="new_password" class="col-sm-3 text-end control-label col-form-label">New Password</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="new_password" />
                                @if($errors->has('new_password'))
                                <span class="text-danger">{{$errors->first('new_password')}}</span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="confirm_password" class="col-sm-3 text-end control-label col-form-label">Confirm Password</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="confirm_password" />
                                @if($errors->has('confirm_password'))
                                <span class="text-danger">{{$errors->first('confirm_password')}}</span>
                                @endif
                            </div>
                        </div>
                </div>
                <div class="border-top">
                    <div class="card-body">
                        <button type="submit" class="btn btn-primary">
                            Submit
                        </button>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
    </div>
</x-layout>
