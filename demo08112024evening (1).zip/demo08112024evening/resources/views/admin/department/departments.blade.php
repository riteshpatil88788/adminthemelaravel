<x-layout>
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <h4 class="page-title"><a href="{{route('add.department')}}" class="btn btn-outline-primary btn-sm">Add+</a></h4>
                <h4 class="page-title" style="margin-left:10px;"><a href="{{route('department.pdf')}}" class="btn btn-outline-secondary btn-sm">PDF</a></h4>
                <h4 class="page-title" style="margin-left:10px;"><a href="{{route('export')}}" class="btn btn-outline-warning btn-sm">Export</a></h4>
                <div class="ms-auto text-end">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{route('list.department')}}">Department</a></li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Department List
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="zero_config1" class="table table-striped table-bordered">
                                <thead>
                                    <tr>

                                        <th>Sno</th>
                                        <th>Department Name</th>
                                        <th>HOD</th>
                                        <th>Start date</th>
                                        <th>No of students</th>
                                        <th>Image</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Right sidebar -->
        <!-- ============================================================== -->
        <!-- .right-sidebar -->
        <!-- ============================================================== -->
        <!-- End Right sidebar -->
        <!-- ============================================================== -->
    </div>
</x-layout>
