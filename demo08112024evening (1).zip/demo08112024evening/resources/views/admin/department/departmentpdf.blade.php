<!DOCTYPE html>
<html>

<head>
    <title>PDF Report</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

    </style>
</head>

<body>
    <h1>Department List</h1>
    <table>
        <thead>
            <tr>
                <th>SNO</th>
                <th>Department ID</th>
                <th>Department Name</th>
                <th>HOD</th>
                <th>Started Date</th>
                <th>No of Students </th>
                <th>Image</th>

            </tr>
        </thead>
        <tbody>
            @foreach ($lists as $index => $list)
            <tr>
                <td>{{ $index + 1 }}</td>
                <td>{{ $list->department_id }}</td>
                <td>{{ $list->department_name }}</td>
                <td>{{ $list->hod }}</td>
                <td>{{ $list->started_date }}</td>
                <td>{{ $list->no_of_students }}</td>
                <td>
                    @if($list->images->isNotEmpty())
                    <img src="{{ public_path('images/' . $list->images->first()->imageable_path) }}" alt="" height="50" width="50">
                    @else
                    <img src="{{ public_path('images/dummy-image.png') }}" alt="No image available" height="50" width="50">
                    @endif
                </td>

            </tr>
            @endforeach
        </tbody>
    </table>
</body>

</html>
