<x-layout>
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <div class="ms-auto text-end">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{route('list.department')}}">Department</a></li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Add Department
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12 mx-auto">
                <div class="card">
                    <form action="{{route('store.department')}}" class="form-horizontal" autocomplete="off" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="card-body">
                            <div class="form-group row">
                                <label for="department_id" class="col-sm-3 text-end control-label col-form-label">Department Id
                                </label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="department_id" value="{{old('department_id')}}" />
                                    @if($errors->has('department_id'))
                                    <span class="text-danger">{{$errors->first('department_id')}}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="department_name" class="col-sm-3 text-end control-label col-form-label">Department Name
                                </label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="department_name" value="{{old('department_name')}}" />
                                    @if($errors->has('department_name'))
                                    <span class="text-danger">{{$errors->first('department_name')}}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="hod" class="col-sm-3 text-end control-label col-form-label">HOD</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="hod" value="{{old('hod')}}" />
                                    @if($errors->has('hod'))
                                    <span class="text-danger">{{$errors->first('hod')}}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="started_date" class="col-sm-3 text-end control-label col-form-label">Started Date</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="datepicker-autoclose" name="started_date" placeholder="MM/DD/YYYY" value="{{old('started_date')}}" />
                                    @if($errors->has('started_date'))
                                    <span class="text-danger">{{$errors->first('started_date')}}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="no_of_students" class="col-sm-3 text-end control-label col-form-label">No of students
                                </label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="no_of_students" value="{{old('no_of_students')}}" />
                                    @if($errors->has('no_of_students'))
                                    <span class="text-danger">{{$errors->first('no_of_students')}}</span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="image" class="col-sm-3 text-end control-label col-form-label">Image
                                </label>
                                <div class="col-sm-9">
                                    <input type="file" class="form-control" name="image" value="{{old('image')}}" />
                                    @if($errors->has('image'))
                                    <span class="text-danger">{{$errors->first('image')}}</span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="description" class="col-sm-3 text-end control-label col-form-label">Message</label>
                                <div class="col-sm-9">
                                    <textarea class="form-control tinymce" id="editor1" name="description" value="{{old('description')}}"></textarea>
                                    @if($errors->has('description'))
                                    <span class="text-danger">{{$errors->first('description')}}</span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="border-top">
                            <div class="card-body">
                                <button type="submit" class="btn btn-primary">
                                    Submit
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-layout>
